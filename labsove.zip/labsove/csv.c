#include <stdio.h>
#include <assert.h>

#include "csv.h"

size_t SplitLine(char *line, char **fields, size_t maxFields) {
    assert(line);
    assert(fields);
    if (maxFields > 0) {
        fields[0] = line;
    }
    size_t count = 1;
    for (size_t i = 0; line[i] != '\0'; i++) {
        if (line[i] == ',') {
            line[i] = '\0';
            if (count < maxFields) {    /* за границу массива не пишем, но считать продолжаем */
                fields[count] = line + i + 1;
            }
            count++;
        }
    }
    return count;
}
