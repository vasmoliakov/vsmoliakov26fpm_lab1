#include <stdio.h>
int IsInt(char *s);
int IsDouble(char *s);
int IsIntegerText(char *s);
long long ParseInt(char *s);
double ParseDouble(char *s);

