enum CsvstatExitCode {
    CSVSTAT_EXIT_OK = 0,
    CSVSTAT_EXIT_ERROR = 1,
    CSVSTAT_EXIT_BAD_CLI = 2
};

