#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "mystring.h"

size_t CountChar(char* arr, char ch) {
    assert(arr);
    size_t k = 0;
    for (size_t i = 0; arr[i] != '\0'; i++) {
        if (arr[i] == ch){
            k += 1;
        }
    }
    return k;
}

int StringCreate(struct myString *buf){
    assert(buf);
    (*buf).capacity = 4;
    (*buf).size = 0;
    (*buf).arr = (char*) calloc((*buf).capacity, sizeof(char));
    if ((*buf).arr == NULL) {
        fprintf(stderr, "error: out of memory\n");
        return -1;
    }
    return 0;
}

int AppendChar(struct myString *buf, char ch) {
    assert(buf);
    if ((*buf).size + 1 > (*buf).capacity) {
        size_t newCapacity = (*buf).capacity * 2;
        char *newArr = realloc((*buf).arr, newCapacity);
        if (newArr == NULL) {
            free(buf->arr);    /* после ошибки строку можно только уничтожить */
            buf->arr = NULL;
            return -1;
        }
        buf->arr = newArr;
        buf->capacity = newCapacity;
    }
    (buf->arr)[buf->size] = ch;
    (buf->size)++;
    return 0;
}

void StringDestroy(struct myString *buf){
    assert(buf);
    (*buf).capacity = 0;
    (*buf).size = 0;
    free((*buf).arr);
    (*buf).arr = NULL;
}

int ReadLine(FILE *f, struct myString *buf) { //читает из файла одну строку до \n
    assert(buf);
    assert(f);
    (*buf).size = 0;
    int p = 0;
    int any = 0;
    while ((p = fgetc(f)) != EOF) {
        any = 1;  //прочитан хотя бы 1 символ, возможно, что это \n, но главное, не конец файла
        if (p == '\n') {
            break;
        }
        if (p == '\r') {
            continue;
        }
        if (AppendChar(buf, (char) p) != 0) { // (char) p - приведение типа, мы проверили, что p - символ => его безопасно превратить в char
            return -1;
        }
    }
    if (AppendChar(buf, '\0') != 0) {
        return -1;
    }
    (*buf).size--;   // '\0' не считаем в размере
    return any;
}
