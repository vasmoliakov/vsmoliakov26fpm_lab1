#include <stdio.h>

// делит строку на поля по запятым, меняя их на '/0'
//fields - массив указателей на поля, maxFields - размер массива
size_t SplitLine(char *line, char **fields, size_t maxFields);

