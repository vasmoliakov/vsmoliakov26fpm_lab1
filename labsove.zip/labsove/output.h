#include "table.h"

void PrintSchema(struct tableInfo *table);
void PrintStats(struct tableInfo *table);

