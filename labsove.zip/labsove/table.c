#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "table.h"
#include "common.h"
#include "mystring.h"
#include "csv.h"
#include "value.h"

int ReadHeader(FILE *f, struct tableInfo *table) { //заполняет имена для столбцов, определяет количество столбцов, выделяет массив столбцов памяти через каллок
    assert(f);
    assert(table);
    struct myString buf;
    if (StringCreate(&buf) != 0) {
        return CSVSTAT_EXIT_ERROR;
    }

    int r = ReadLine(f, &buf);
    if (r < 0) {
        fprintf(stderr, "error: out of memory\n");
        return CSVSTAT_EXIT_ERROR;
    }
    if (r == 0) {
        fprintf(stderr, "error: file is empty\n");
        StringDestroy(&buf);
        return CSVSTAT_EXIT_ERROR;
    }

    table->headerBuf = buf.arr;
    table->numOfColumns = CountChar(table->headerBuf, ',') + 1;

    table->columns = calloc(table->numOfColumns, sizeof(struct columnInfo));
    table->fields = calloc(table->numOfColumns, sizeof(char *));
    if (table->columns == NULL || table->fields == NULL) {
        fprintf(stderr, "error: out of memory\n");
        return CSVSTAT_EXIT_ERROR;
    }

    SplitLine(table->headerBuf, table->fields, table->numOfColumns); //заполняет имена столбцов
    for (size_t i = 0; i < table->numOfColumns; i++) {
        table->columns[i].name = table->fields[i];
    }
    return CSVSTAT_EXIT_OK;
}

int ReadRecord(FILE *f, struct myString *line, struct tableInfo *table) { //ридлайн+сплитлайн
    int r = ReadLine(f, line);
    if (r < 0) {
        fprintf(stderr, "error: out of memory\n");
        return -1;
    }
    if (r == 0) {
        return 0;
    }
    size_t n = SplitLine(line->arr, table->fields, table->numOfColumns);
    if (n != table->numOfColumns) {
        fprintf(stderr, "error: row has %zu fields, expected %zu\n", n, table->numOfColumns);
        return -1;
    }
    return 1;
}


int UpdateTypes(struct tableInfo *table) {
    for (size_t i = 0; i < table->numOfColumns; i++) {
        char *field = table->fields[i];
        if (IsDouble(field)) {
            table->columns[i].type = TYPE_DOUBLE;
        } else if (IsInt(field) == 0) {
            fprintf(stderr, "error: bad value \"%s\" in column %zu\n", field, i);
            return CSVSTAT_EXIT_ERROR;
        }
    }
    return CSVSTAT_EXIT_OK;
}

int DetectTypes(FILE *f, struct tableInfo *table) {
    assert(f);
    assert(table);
    struct myString line;
    if (StringCreate(&line) != 0) {
        return CSVSTAT_EXIT_ERROR;
    }

    int res = CSVSTAT_EXIT_OK;
    int r = ReadRecord(f, &line, table);
    while (r == 1 && res == CSVSTAT_EXIT_OK) {
        table->numOfRows++;
        res = UpdateTypes(table);
        if (res == CSVSTAT_EXIT_OK) {
            r = ReadRecord(f, &line, table);
        }
    }
    if (r < 0) {
        res = CSVSTAT_EXIT_ERROR;
    }

    StringDestroy(&line);
    return res;
}

void AddIntValue(struct columnInfo *col, long long v) {
    if (col->count == 0 || v < col->minInt) {
        col->minInt = v;
    }
    if (col->count == 0 || v > col->maxInt) {
        col->maxInt = v;
    }
    if (v > 0) {
        col->positive++;
    }
    if (v < 0) {
        col->negative++;
    }
    if (v % 2 == 0) {     
        col->even++;
    }
    col->sumInt += v;
    col->count++;
}

void AddDoubleValue(struct columnInfo *col, char *text) {
    double x = ParseDouble(text);
    if (col->count == 0 || x < col->minDouble) {
        col->minDouble = x;
    }
    if (col->count == 0 || x > col->maxDouble) {
        col->maxDouble = x;
    }
    if (x > 0.0) {        // -0.0 > 0.0 и -0.0 < 0.0 оба ложны: ноль никуда не попадает 
        col->positive++;
    }
    if (x < 0.0) {
        col->negative++;
    }
    if (IsIntegerText(text)) {
        col->integer++;
    }
    col->sumDouble += x;
    col->count++;
}


void UpdateStats(struct tableInfo *table) {
    for (size_t i = 0; i < table->numOfColumns; i++) {
        struct columnInfo *col = &table->columns[i];
        if (col->type == TYPE_INT) {
            AddIntValue(col, ParseInt(table->fields[i]));
        } else {
            AddDoubleValue(col, table->fields[i]);
        }
    }
}

int CollectStats(FILE *f, struct tableInfo *table) {
    assert(f);
    assert(table);
    rewind(f);

    struct myString line;
    if (StringCreate(&line) != 0) {
        return CSVSTAT_EXIT_ERROR;
    }

    int res = CSVSTAT_EXIT_OK;
    int r = ReadLine(f, &line);   
    if (r < 0) {
        fprintf(stderr, "error: out of memory\n");
        res = CSVSTAT_EXIT_ERROR;
    }
    if (res == CSVSTAT_EXIT_OK) {
        r = ReadRecord(f, &line, table);
        while (r == 1) {
            UpdateStats(table);
            r = ReadRecord(f, &line, table);
        }
        if (r < 0) {
            res = CSVSTAT_EXIT_ERROR;
        }
    }

    StringDestroy(&line);
    return res;
}

double ColumnMean(struct columnInfo *col) {
    assert(col);
    if (col->count == 0) {
        return 0.0;
    }
    if (col->type == TYPE_DOUBLE) {
        return col->sumDouble / (double) col->count;
    }
    // sum = q * count + r, поэтому mean = q + r / count.
    //q помещается в long long (среднее не больше максимума), |r| < count 
    long long q = (long long) (col->sumInt / (__int128) col->count);
    long long r = (long long) (col->sumInt % (__int128) col->count);
    return (double) q + (double) r / (double) col->count;
}

void TableDestroy(struct tableInfo *table) {
    assert(table);
    free(table->headerBuf);
    free(table->columns);
    free(table->fields);
    table->headerBuf = NULL;
    table->columns = NULL;
    table->fields = NULL;
    table->numOfColumns = 0;
    table->numOfRows = 0;
}
