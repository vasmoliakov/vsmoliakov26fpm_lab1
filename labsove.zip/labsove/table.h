#include <stdio.h>

enum ColumnType {
    TYPE_INT = 0,
    TYPE_DOUBLE
};

struct columnInfo {
    char *name;
    enum ColumnType type;
    size_t count;
    size_t positive;
    size_t negative;
    size_t even;
    size_t integer;
    long long minInt;
    long long maxInt;
    __int128 sumInt;

    double minDouble;
    double maxDouble;
    double sumDouble;
};

struct tableInfo {
    size_t numOfColumns;
    size_t numOfRows;
    char *headerBuf;
    struct columnInfo *columns;
    char **fields;
};

int ReadHeader(FILE *f, struct tableInfo *table);
int DetectTypes(FILE *f, struct tableInfo *table);
int CollectStats(FILE *f, struct tableInfo *table);

double ColumnMean(struct columnInfo *col);
void TableDestroy(struct tableInfo *table);


