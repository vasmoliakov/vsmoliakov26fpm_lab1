#include <stdio.h>
#include <string.h>

#include "common.h"
#include "table.h"
#include "output.h"

void PrintHelp(void) {
    printf("Usage:\n");
    printf("  a.exe --help\n");
    printf("  a.exe schema <csv-file>\n");
    printf("  a.exe stats <csv-file>\n");
}

// выполняет schema или stats для файла, возвращает код завершения 
int RunCommand(char *command, char *fileName) {
    int isStats = (strcmp(command, "stats") == 0);

    FILE *f = fopen(fileName, "r");
    if (f == NULL) {
        fprintf(stderr, "error: cannot open file %s\n", fileName);
        return CSVSTAT_EXIT_ERROR;
    }

    struct tableInfo table = {0};
    int res = ReadHeader(f, &table);
    if (res == CSVSTAT_EXIT_OK) {
        res = DetectTypes(f, &table);
    }
    if (res == CSVSTAT_EXIT_OK && isStats) {
        res = CollectStats(f, &table);
    }

    if (res == CSVSTAT_EXIT_OK && isStats) {
        PrintStats(&table);
    }
    if (res == CSVSTAT_EXIT_OK && isStats == 0) {
        PrintSchema(&table);
    }

    TableDestroy(&table);
    fclose(f);
    return res;
}

int main(int argc, char *argv[]) {
    if (argc == 2 && strcmp(argv[1], "--help") == 0) {
        PrintHelp();
        return CSVSTAT_EXIT_OK;
    }
    if (argc == 3 && (strcmp(argv[1], "schema") == 0 || strcmp(argv[1], "stats") == 0)) {
        return RunCommand(argv[1], argv[2]);
    }
    fprintf(stderr, "error: wrong arguments, see a.exe --help\n");
    return CSVSTAT_EXIT_BAD_CLI;
}
