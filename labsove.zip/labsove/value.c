#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "value.h"

size_t CountDigits(char *s) { 
    size_t i = 0;
    while (s[i] >= '0' && s[i] <= '9') {
        i++;
    }
    return i;
}

size_t SignLength(char *s) {
    if (s[0] == '+' || s[0] == '-') {
        return 1;
    }
    return 0;
}

int IsInt(char *s) {
    assert(s);
    size_t i = SignLength(s);
    s += i;
    size_t digits = CountDigits(s);
    if (digits == 0) {
        return 0;
    }
    s += digits;
    return (*s == '\0');
}


int IsDouble(char *s) {
    assert(s);
    size_t i = SignLength(s);
    s += i;
    size_t digits = CountDigits(s);  
    if (digits == 0) {
        return 0;
    }
    s += digits;
    if (*s != '.') {
        return 0;
    }
    s++;                              
    digits = CountDigits(s);          
    if (digits == 0) {
        return 0;
    }
    s += digits;
    return (*s == '\0');
}

int IsIntegerText(char *s) {
    assert(s);
    while (*s != '\0' && *s != '.') {
        s++;
    }
    if (*s == '\0') {                 
        return 1;
    }
    s++;                              
    while (*s != '\0') {
        if (*s != '0') {
            return 0;
        }
        s++;
    }
    return 1;
}

long long ParseInt(char *s) {
    assert(s);
    return strtoll(s, NULL,10);
}


double ParseDouble(char *s) {
    assert(s);
    return strtod(s, NULL);
}
