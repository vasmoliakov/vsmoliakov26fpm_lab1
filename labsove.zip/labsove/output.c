#include <stdio.h>
#include <assert.h>

#include "output.h"

char *TypeName(enum ColumnType type) {
    if (type == TYPE_DOUBLE) {
        return "DOUBLE";
    }
    return "INT";
}

/* печатает вещественное число с 6 знаками, ноль - всегда как 0.000000, без минуса */
void PrintDouble(double x) {
    if (x >= -0.0000005 && x <= 0.0000005) {
        x = 0.0;
    }
    printf("%.6f", x);//6 знаков после запятой
}

void PrintTableSize(struct tableInfo *table) {
    printf("rows %zu\n", table->numOfRows);
    printf("columns %zu\n", table->numOfColumns);
}

void PrintSchema(struct tableInfo *table) {
    assert(table);
    PrintTableSize(table);
    for (size_t i = 0; i < table->numOfColumns; i++) {
        printf("%zu ", i);
        printf("%s",table->columns[i].name);
        printf(" %s\n", TypeName(table->columns[i].type));
    }
}

void PrintIntColumn(struct columnInfo *col) {
    printf("min %lld\n", col->minInt);
    printf("max %lld\n", col->maxInt);
    printf("mean ");
    PrintDouble(ColumnMean(col));
    printf("\n");
    printf("positive %zu\n", col->positive);
    printf("negative %zu\n", col->negative);
    printf("even %zu\n", col->even);
}

void PrintDoubleColumn(struct columnInfo *col) {
    printf("min ");
    PrintDouble(col->minDouble);
    printf("\nmax ");
    PrintDouble(col->maxDouble);
    printf("\nmean ");
    PrintDouble(ColumnMean(col));
    printf("\n");
    printf("positive %zu\n", col->positive);
    printf("negative %zu\n", col->negative);
    printf("integer %zu\n", col->integer);
}

void PrintStats(struct tableInfo *table) {
    assert(table);
    PrintTableSize(table);
    for (size_t i = 0; i < table->numOfColumns; i++) {
        struct columnInfo *col = &table->columns[i];
        printf("\n");
        printf("column %zu\n", i);
        printf("name %s",col->name);
        printf("\n");
        printf("type %s\n", TypeName(col->type));
        printf("nulls 0\n");           
        if (col->type == TYPE_INT) {
            PrintIntColumn(col);
        } else {
            PrintDoubleColumn(col);
        }
    }
}
