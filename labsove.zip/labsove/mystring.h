#include <stdio.h>

struct myString{
    size_t capacity;   // сколько байт выделено 
    size_t size;       // сколько символов лежит (без '\0')
    char* arr;
};

int StringCreate(struct myString *buf);
int AppendChar(struct myString *buf, char ch);
void StringDestroy(struct myString *buf);
int ReadLine(FILE *f, struct myString *buf);
size_t CountChar(char* arr, char ch);
